int main()
{
	int a,b,c;
	readi(&a);
	readi(&b);
	c = a+b;
	printi(c);
	return 0;
}