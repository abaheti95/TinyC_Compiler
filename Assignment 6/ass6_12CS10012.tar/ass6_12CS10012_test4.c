int main()
{
	char a,b;
	int c=0;
	a = '1';
	b = 'A';
	if(a>b)
	{
		c++;
	}
	else
	{
		c--;
	}
	printi(c);
	return 0;
}