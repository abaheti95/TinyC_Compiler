//function declaration

double function(int a,int b);
//main function

int main()
{
	int a;
	int b,c;
	double d1,*d2;
	char *cp,ch='z';
	int i=10;
	int j=i+7;
	double dbl = 5.5;
	int arr[100];
	double arr2[30][40],second;
	int **ipp;
	return dbl;
}

double function(int a,int b)
{
	int x;
	char c = 'f';
	double y=x;
	return y;
}
