int main()
{
	// asdlkjfalf;
	int a = int b;
	return 10;
}