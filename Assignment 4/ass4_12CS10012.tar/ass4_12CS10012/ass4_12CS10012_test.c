inline int max(int a,int b)
{return (a<b)?b:a;}

static int main(int argc, char const *argv[])
{
	auto int a;
	scanf("%d",&a);
	switch(a)
	{
		case 10: printf("0");break;
		case 1: break;
		default:
			/* Do nothing */break;
	}
	putchar('\n');
	const char*s123;
	int G[100];

	for(int i=1 	;	i< 10 ; i++	)
		continue;
	int iterator=10;
	do
	{
		--iterator;
	}while(iterator > 10);
	

	float f1 = -1234.134e21;
	float f2 = +12.12;
	float f3 = .56;
	float f4 = 		-658;
	f1=f2+f3;f3 = 		f1/f2;
	a %= 10;
	a+=30;

	goto A;
	
	unsigned long long int b = ~10;
	register char ch = 'a';
	short val = 10%4;

	_Bool ha;
	_Complex hb,hc;
	_Imaginary hb1;
	
	root->next = NULL;
	root-> val =a;
	a = !((a>>1)|(a<<1)&a);
	
	if(a<10 || a==10 && f1 >= 0.0)
	{


		a = 10;
	}
	else if( f1!=0.0)
		a++;
	
	b^=b;
	
	return 10;
}